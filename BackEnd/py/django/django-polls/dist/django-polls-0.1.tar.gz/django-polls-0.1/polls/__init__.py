# coding=utf-8

import pymysql
pymysql.install_as_MySQLdb()